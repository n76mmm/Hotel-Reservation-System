public class Guest implements Displayable {
   private String id;
   private String name;
   private String phone;

   public Guest(String id, String name, String phone) {
      this.id = id;
      this.name = name;
      this.phone = phone;
   }

   
   public void displayInfo() {//override
      System.out.println("Guest ID: " + id);
      System.out.println("Name: " + name);
      System.out.println("Phone: " + phone);
   }

   public String getGuestId() {
      return id;
   }

   public String getName() {
      return name;
   }

   public String getPhoneNumber() {
      return phone;
   }

   public void setGuestId(String id) {
      this.id = id;
   }

   public void setName(String name) {
      this.name = name;
   }

   public void setPhoneNumber(String phone) {
      this.phone = phone;
   }
}